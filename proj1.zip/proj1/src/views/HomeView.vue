<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png">
<h1>Welcon to F1</h1>
<img v-if="usuario == 'Homero'" src="../assets/homero.jpg" class="img">
<h1>{{ usuario }}</h1>
<input v-model="usuario" type="text">
<button v-on:click="cambiaValor">cambiar</button>
  <div>
    <li v-for="item in items">
      {{ item.title }}
    </li>
  </div>
</div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'
import axios from 'axios'
export default {
  name: 'HomeView',
  data() {
    return {
      usuario:"",
      password:"",
      items: []
    }
  },
  methods: {
    cambiaValor(){
      this.usuario = "Lisa"
    },
    async otraFuncion(){
      const response = await axios.get('https://jsonplaceholder.typicode.com/posts')
    console.log(response)
    this.items = response.data
    }
  },
  mounted(){
this.otraFuncion()
this.usuario = "Homero"
  },
  components: {
    
  }
}
</script>

<style scoped>
.img{
  width: 200px;
  height: 200px;
  border-radius: 50%;
}
</style>
