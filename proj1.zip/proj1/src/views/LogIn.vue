<template>
    <div ng-app="App" class="page-container">
        <div class="form-container" ng-class="done">
            <div class="login-form">
                <h3 class="title">SmartDose</h3>
                <div>
                    <input type="text" placeholder="Email" v-model="email" @input="validateForm">
                    <span v-if="!isEmailValid && emailTouched" class="error-message">Por favor ingresa un correo
                        valido</span>
                </div>

                <div>
                    <input type="password" placeholder="Password" v-model="password" @input="validateForm">
                </div>

                <button :disabled="!isFormValid" @click="logInFunction">
                    <span>Iniciar sesión</span>
                </button>
            </div>
        </div>
    </div>
</template>

<script>
import axios from 'axios';
export default {

    name: 'LogIn',
    data() {
        return {
            email: '',
            password: '',
            isFormValid: false,
            isEmailValid: true,
            emailTouched: false
        };
    },
    methods: {
        validateForm() {
            this.emailTouched = true;
            this.isEmailValid = this.validateEmail(this.email);
            this.isFormValid = this.isEmailValid && this.email !== '' && this.password !== '';
        },
        validateEmail(email) {
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailPattern.test(email);
        },
        logIn() {
            if (this.isFormValid) {
                alert(`Ingreso con el correo: ${this.email} y la contraseña: ${this.password}`);
            }
        },

        async logInFunction() {
            try {
                const params = {
                    password: this.password,
                    correo: this.email
                };
                const response = await axios.get('http://localhost:3000/login', { params })
                console.log(response)
                this.items = response.data
            } catch (error) {
                console.error(error);
            }
        },

    },
};
</script>

<style scoped>
button {
    background: #4d4c6e;
    border: 1px solid #4d4c6e;
    color: #e8eeea;
    padding: 10px 70px;
    font-size: 20px;
    position: relative;
    outline: none;
    cursor: pointer;
    min-width: 300px;
    border-radius: 100px;
}

button:not([disabled]):hover {
    background: #6b5f83;
}

button[disabled] {
    background: #d9dbda;
    color: #ffffff3b;
    cursor: default;
}

button.loading:after {
    opacity: 1;
    left: 15px;
}

* {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}

body {
    background: #ededed;
    font-family: Arial, sans-serif;
}

a {
    color: #7f8c8d;
}

.form-container {
    padding: 50px 40px;
    background: #fff;
    width: 400px;
    text-align: center;
    box-shadow: 1px 1px 3px 3px rgba(0, 0, 0, 0.2);
    margin: 0 auto;
    transition: all 1s linear;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}

.form-container:after {
    content: "";
    display: block;
    position: absolute;
    top: 0;
    left: 0;
    width: 100px;
    height: 10px;
    background: #6b5f83;
    box-shadow: 100px 0 0 #5e8f96, 200px 0 0 #8db4af, 300px 0 0 #b1c2af;
}

.form-container h3 {
    font-size: 32px;
    text-align: center;
    color: #666;
    margin: 0 0 30px;
}

.login-form {
    padding-top: 50px;
}

.form-container .login-form>div {
    margin-bottom: 20px;
}

.form-container .login-form>div>input {
    border: 2px solid #dedede;
    padding: 20px;
    font-size: 20px;
    min-width: 300px;
    color: #666;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    border-radius: 3px;
    outline: none;
    -webkit-transition: border-color 0.2s linear;
    -moz-transition: border-color 0.2s linear;
    transition: border-color 0.2s linear;
}

.form-container .login-form>div>input:focus {
    border-color: #A5A5A5;
}

.page-container {
    min-height: 500px;
}

.error-message {
    color: red;
    font-size: 14px;
    margin-top: 5px;
    display: block;
}
</style>
